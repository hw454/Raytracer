#!/usr/bin/env python3
# Hayley Wragg 2018-05-29
'''This program contains the ray tracer function. This function takes
ray tracing inputs and outputs a mesh containing information about the
rays.'''

def raytracer(Room, Tx, Nra, Nre, h):
  # Mesh=rmes.mesh(Room,h,Nra,Nre)
 return Mesh
